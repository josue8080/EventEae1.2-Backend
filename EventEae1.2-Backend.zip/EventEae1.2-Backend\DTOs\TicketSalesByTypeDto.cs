﻿namespace EventEae1._2_Backend.DTOs
{
    public class TicketSalesByTypeDto
    {
        public string Name { get; set; }
        public int TotalQuantitySold { get; set; }

       
    }
}
