﻿namespace EventEae1._2_Backend.DTOs
{
    public class UploadEventImageDto
    {
        public IFormFile Image { get; set; }
       
    }
}
