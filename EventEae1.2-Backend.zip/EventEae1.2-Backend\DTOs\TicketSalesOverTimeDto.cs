﻿namespace EventEae1._2_Backend.DTOs
{
    public class TicketSalesOverTimeDto
    {
        public DateTime TimePeriod { get; set; } 
        public int TicketsSold { get; set; }
    }
}
